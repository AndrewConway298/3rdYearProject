package Proto.Game.States;

import java.awt.Graphics;

import Proto.Game.Game;

public class OptionsState extends State{
	public OptionsState(Game game){
		super(game);
	}
	@Override
	public void update() {
	
	}

	@Override
	public void render(Graphics g) {
	
	}

}
