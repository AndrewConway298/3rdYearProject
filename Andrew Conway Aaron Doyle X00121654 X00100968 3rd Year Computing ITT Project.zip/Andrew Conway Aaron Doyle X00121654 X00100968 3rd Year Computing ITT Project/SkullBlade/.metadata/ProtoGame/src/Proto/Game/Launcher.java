package Proto.Game;

public class Launcher {
	public static void main(String[] args){
		//Standard Size
		Game game = new Game("Prototype", 920, 500);
		//Game game = new Game("Prototype", 1600, 500);
		game.start();
	}
}
