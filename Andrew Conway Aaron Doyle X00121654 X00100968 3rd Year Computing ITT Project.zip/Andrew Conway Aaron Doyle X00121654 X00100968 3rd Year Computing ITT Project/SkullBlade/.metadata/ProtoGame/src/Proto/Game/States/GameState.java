package Proto.Game.States;

import java.awt.Graphics;

import Proto.Game.Game;
import Proto.Game.Entities.Creatures.Player;
import Proto.Game.Entities.Creatures.Skull;

public class GameState extends State{
	
	private Player player;
	private Skull skull;
	
	public GameState(Game game){
		super(game);
		player = new Player(game, 0, 300);
		skull = new Skull(850, 300);
	}
	
	public void update() {
		player.update();
		skull.update();
	}

	public void render(Graphics g) {
		player.render(g);
		skull.render(g);
	}
	
}
