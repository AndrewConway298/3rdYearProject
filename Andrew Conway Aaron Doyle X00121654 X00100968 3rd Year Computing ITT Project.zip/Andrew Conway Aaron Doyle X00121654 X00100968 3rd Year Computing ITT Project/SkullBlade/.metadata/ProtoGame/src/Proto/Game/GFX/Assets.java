package Proto.Game.GFX;

import java.awt.image.BufferedImage;
//HOLDS ALL ASSETS SUCH AS IMAGES, MUSIC, ETC.
public class Assets {
	public static final int width = 70, height = 90;
	public static BufferedImage player, skull;
	
	public static void init(){
		SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/CharSprite1.png"));
		player = sheet.crop(0, 0, width, height);
		SpriteSheet sheet2 = new SpriteSheet(ImageLoader.loadImage("/textures/SkullEnemyLeft.png"));
		skull = sheet2.crop(0, 0, width, height);
	}
}
