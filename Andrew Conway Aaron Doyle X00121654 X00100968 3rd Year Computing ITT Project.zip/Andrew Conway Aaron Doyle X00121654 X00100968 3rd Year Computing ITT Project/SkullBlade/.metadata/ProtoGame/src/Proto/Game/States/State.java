package Proto.Game.States;

import java.awt.Graphics;

import Proto.Game.Game;

public abstract class State {
	//GAME STATE MANAGER
	private static State curState = null;
	
	public static void setState(State state){
		curState = state;
	}
	
	public static State getState(){
		return curState;
	}
	//CLASS
	protected Game game;
	
	public State(Game game){
		this.game = game;
	}
	
	public abstract void update();
	
	public abstract void render(Graphics g);
}
