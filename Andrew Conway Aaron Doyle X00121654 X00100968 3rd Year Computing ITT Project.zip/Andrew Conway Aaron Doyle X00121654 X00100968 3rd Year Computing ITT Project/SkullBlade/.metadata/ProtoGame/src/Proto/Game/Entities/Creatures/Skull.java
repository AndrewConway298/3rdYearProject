package Proto.Game.Entities.Creatures;

import java.awt.Graphics;

import Proto.Game.GFX.Assets;

public class Skull extends Creature{

	public Skull(float x, float y) {
		super(x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		x-=1;
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(Assets.skull, (int) x, (int) y, width, height, null);
	}

}
