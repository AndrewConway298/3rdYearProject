package Proto.Game;

import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import Proto.Game.Display.Display;
import Proto.Game.GFX.Assets;
import Proto.Game.GFX.ImageLoader;
import Proto.Game.Input.KeyManager;
import Proto.Game.States.GameState;
import Proto.Game.States.MenuState;
import Proto.Game.States.OptionsState;
import Proto.Game.States.State;

public class Game implements Runnable{
	//Attributes
		private Display display;
		public String title;
		public int width, height;
		//Thread
		private boolean running = false;
		private Thread thread;
		//Graphics
		private BufferStrategy bs;
		private Graphics g;
		//Images
		private BufferedImage BG;
		//States
		private State gameState;
		private State menuState;
		private State optionsState;
		//Inputs
		private KeyManager keyManager;
		//Constructor
		public Game(String title, int width, int height){
			this.width = width;
			this.height = height;
			this.title = title;
			keyManager = new KeyManager();
		}
		//methods
		//Initializes
		private void init(){
			display = new Display(title, width, height);
			display.getFrame().addKeyListener(keyManager);
			BG = ImageLoader.loadImage("/textures/test.png");
			Assets.init();
			gameState = new GameState(this);
			menuState = new MenuState(this);
			optionsState = new OptionsState(this);
			State.setState(gameState);
		}
		//Updates
		private void update(){
			keyManager.update();
			if(State.getState() != null){
				State.getState().update();
			}
		}
		//Renders(Draw)
		private void render(){
			bs = display.getCanvas().getBufferStrategy();
			if(bs == null){
				display.getCanvas().createBufferStrategy(3);
				return;
			}
			g = bs.getDrawGraphics();
			//Clear Screen
			g.clearRect(0, 0, width, height);
			//Draw Here!
			g.drawImage(BG, 0, 0, null);
			if(State.getState() != null){
				State.getState().render(g);
			}
			//End Drawing
			bs.show();
			g.dispose();
		}
		//Main run method
		public void run(){
			//Limiting FPS
			int fps = 60;
			double timePerTick = 1000000000 / fps;//measures time in nano seconds.
			double delta = 0;
			long now;
			long lastTime = System.nanoTime();//returns current time in nano seconds.
			long timer = 0;
			int ticks = 0;
			
			init();
			while(running){
				now = System.nanoTime();
				delta += (now - lastTime) / timePerTick;
				timer += now - lastTime;
				lastTime = now;
				if(delta >= 1){
				update();
				render();
				ticks ++;
				delta --;
				}
				//checks fps
				if(timer >= 1000000000){
					System.out.println("FPS : " + ticks);
					ticks = 0;
					timer = 0;
				}
			}
			stop();
		}
		
		public KeyManager getKeyManager(){
			return keyManager;
		}
		
		//Starts Thread
		public synchronized void start(){
			if(running){
				return;
			}
			else
			running = true;
			thread = new Thread(this);
			thread.start();
		}
		//Stops Thread
		public synchronized void stop(){
			if(!running){
				return;
			}
			else
				running = false;
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
}
