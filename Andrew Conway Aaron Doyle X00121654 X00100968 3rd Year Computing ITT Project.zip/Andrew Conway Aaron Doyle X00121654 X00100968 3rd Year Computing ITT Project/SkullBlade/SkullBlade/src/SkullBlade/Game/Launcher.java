package SkullBlade.Game;

import SkullBlade.Game.Audio.AudioPlayer;

public class Launcher {
	//Contains main method to 'launch' game
	public static void main(String[] args){
		//Standard Size
		Game game = new Game("SkullBlade", 900, 500);
		//Alternate size for screen
		//Game game = new Game("SkullBlade", 1600, 500);
		game.start();
		//Used to start audio(unable to actually play audio)
		AudioPlayer audioPlayer = new AudioPlayer(null);
		//audioPlayer.play();
		audioPlayer.loop(1);
	}
}
