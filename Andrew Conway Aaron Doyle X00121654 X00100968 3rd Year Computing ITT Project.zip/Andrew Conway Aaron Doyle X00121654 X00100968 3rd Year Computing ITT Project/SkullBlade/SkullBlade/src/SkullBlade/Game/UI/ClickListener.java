package SkullBlade.Game.UI;

public interface ClickListener {
	//Listens for a click
	public void onClick();

}
