package SkullBlade.Game.Tiles;

import SkullBlade.Game.GFX.Assets;

public class BrownTile extends Tile{
	//Assigns tile texture to corresponding image in Assets and ID
	public BrownTile(int id) {
        super(Assets.brown, id);
    }
}
