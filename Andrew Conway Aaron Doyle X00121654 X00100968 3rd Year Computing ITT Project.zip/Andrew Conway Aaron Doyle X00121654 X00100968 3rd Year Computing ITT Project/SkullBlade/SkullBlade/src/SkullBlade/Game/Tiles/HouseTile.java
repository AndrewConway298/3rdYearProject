package SkullBlade.Game.Tiles;

import SkullBlade.Game.GFX.Assets;

public class HouseTile extends Tile{
	//Assigns tile texture to corresponding image in Assets and ID
	public HouseTile(int id) {
        super(Assets.house, id);
    }
}
