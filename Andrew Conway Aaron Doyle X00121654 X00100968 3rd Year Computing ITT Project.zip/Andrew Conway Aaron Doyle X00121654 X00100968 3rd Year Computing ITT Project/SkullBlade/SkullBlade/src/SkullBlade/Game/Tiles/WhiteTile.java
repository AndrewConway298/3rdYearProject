package SkullBlade.Game.Tiles;

import SkullBlade.Game.GFX.Assets;

public class WhiteTile extends Tile{
	//Assigns tile texture to corresponding image in Assets and ID
	public WhiteTile(int id) {
        super(Assets.white, id);
    }
	//Sets tile to be solid
	public boolean isSolid(){
        return true;
    }
}
