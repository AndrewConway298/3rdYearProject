package SkullBlade.Game.Tiles;

import SkullBlade.Game.GFX.Assets;

public class ChapelTile extends Tile{
	//Assigns tile texture to corresponding image in Assets and ID
	public ChapelTile(int id) {
        super(Assets.chapel, id);
    }
}
