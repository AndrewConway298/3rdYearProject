package SkullBlade.Game.Tiles;

import SkullBlade.Game.GFX.Assets;

public class PathTile extends Tile{
	//Assigns tile texture to corresponding image in Assets and ID
	public PathTile(int id) {
        super(Assets.path, id);
    }

}
