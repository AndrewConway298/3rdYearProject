package SkullBlade.Game.Tiles;

import SkullBlade.Game.GFX.Assets;

public class PurpleTile extends Tile{
	public PurpleTile(int id) {
        super(Assets.purple, id);
    }
}
