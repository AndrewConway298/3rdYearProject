package SkullBlade.Game.Tiles;

/*
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Tile {
	//Static
	public static Tile[] levels = new Tile[256];
	public static Tile tileClear = new tileClear(0);
	public static Tile tileSolid = new tileSolid(1);
	//Class
	public static final int LVLWIDTH = 25, LVLHEIGHT = 15;

	protected BufferedImage texture;
	protected final int id;

	public Tile(BufferedImage texture, int id){
		this.texture = texture;
		this.id = id;
		
		levels[id] = this;
	}
	
	public void update(){
		
	}
	
	public void render(Graphics g, int x, int y){
		g.drawImage(texture, x, y, LVLWIDTH, LVLHEIGHT, null);
	}
	
	public boolean isSolid(){
		return false;
	}
	
	public int getId() {
		return id;
	}
}
*/

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Tile {
	//Attributes(Static)
	public static Tile[] levels = new Tile[256];
	public static Tile tilePurple = new PurpleTile(0);
	public static Tile tileChapel = new ChapelTile(1);
	public static Tile tileGreen = new GreenTile(2);
	public static Tile tileHouse = new HouseTile(3);
	public static Tile tilePath = new PathTile(4);
	public static Tile tileBrown = new BrownTile(5);
	public static Tile tileRed = new RedTile(6);
	public static Tile tileWhite = new WhiteTile(7);
	//Attributes
	public static final int LVLWIDTH = 103, LVLHEIGHT = 34;
	protected BufferedImage texture;
	protected final int id;
	//Constructor
	public Tile(BufferedImage texture, int id){
		this.texture = texture;
		this.id = id;
		levels[id] = this;
	}
	//Update
	public void update(){
		
	}
	//Renders current tile
	public void render(Graphics g, int x, int y){
		g.drawImage(texture, x, y, LVLWIDTH, LVLHEIGHT, null);
	}
	//Checks if tile is solid(Standardly set to false to allow player to pass through)
	public boolean isSolid(){
		return false;
	}
	//Getters
	public int getId(){
		return id;
	}
	
}

