package SkullBlade.Game.Tiles;

import SkullBlade.Game.GFX.Assets;

public class GreenTile extends Tile{
	//Assigns tile texture to corresponding image in Assets and ID
	public GreenTile(int id) {
        super(Assets.green, id);
    }
}
