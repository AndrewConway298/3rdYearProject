package SkullBlade.Game;

import SkullBlade.Game.GFX.GameCamera;
import SkullBlade.Game.Input.KeyManager;
import SkullBlade.Game.Input.MouseManager;
import SkullBlade.Game.Worlds.World;

public class Handler {
	//Class allows access to other classes remotely and removes any need for calling multiples of the same class
	//Attributes
	private Game game;
	private World world;
	//Constructor
	public Handler(Game game){
		this.game = game;
	}
	//Getters & Setters
	public int getWidth(){
		return game.getWidth();
	}
	
	public int getHeight(){
		return game.getHeight();
	}
	
	public KeyManager getKeyManager(){
		return game.getKeyManager();
	}
	
	public MouseManager getMouseManager(){
		return game.getMouseManager();
	}
	
	public GameCamera getGameCamera(){
		return game.getGameCamera();
	}

	public Game getGame() {
		return game;
	}
	
	public World getWorld() {
		return world;
	}

	public void setGame(Game game) {
		this.game = game;
	}

	public void setWorld(World world) {
		this.world = world;
	}
}
