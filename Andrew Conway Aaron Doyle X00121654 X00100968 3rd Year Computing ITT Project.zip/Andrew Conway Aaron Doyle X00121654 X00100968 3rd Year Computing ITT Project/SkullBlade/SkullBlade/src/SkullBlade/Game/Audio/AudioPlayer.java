package SkullBlade.Game.Audio;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import SkullBlade.Game.Handler;

public class AudioPlayer {
	/***
	*    Usage: <Used>
	*    Title: <SOUND>
	*    Author: <kpars>
	*    Date: <24/04/2017>
	*    Code version: <V1>
	*    Availability: http://www.java-gaming.org/index.php?topic=30545.0
	*
	***/
	//Plays music
	private static Handler handler;
	//Constructor
	public AudioPlayer(Handler handler) {
		this.handler = handler;
		play();
	}
	//Creates an Audio Player and loads in the file
	public static AudioPlayer music = loadSound("/music/test.wav");
	//Creates a clip
	private Clip clip;
	
	 public static AudioPlayer loadSound(String fileName) {
		   AudioPlayer sound = new AudioPlayer(handler);
	      try {
	         AudioInputStream ais = AudioSystem.getAudioInputStream(AudioPlayer.class
	               .getResource(fileName));
	         Clip clip = AudioSystem.getClip();
	         clip.open(ais);
	         sound.clip = clip;
	      } catch (Exception e) {
	         System.out.println(e);
	      }
	      return sound;
	   }

	   public void loop(final int delta) {
	      try {
	         if (clip != null)
	            new Thread() {
	               public void run() {
	                  synchronized (clip) {
	                     clip.stop();
	                     clip.setFramePosition(0);
	                     clip.loop(delta);
	                  }
	               }
	            }.start();
	      } catch (Exception e) {
	         e.printStackTrace();
	         System.exit(0);
	      }
	   }

	   public void play() {
	      try {
	         if (clip != null)
	            new Thread() {
	               public void run() {
	                  synchronized (clip) {
	                     clip.stop();
	                     try {
	                        Thread.sleep(45);
	                        clip.setFramePosition(0);
	                        clip.start();
	                     } catch (InterruptedException e) {}
	                  }
	               }
	            }.start();
	      } catch (Exception e) {
	         e.printStackTrace();
	         System.exit(0);
	      }
	   }
	
}
