package SkullBlade.Game.GFX;

import java.awt.image.BufferedImage;

public class Animation {
	//Attributes
	private int speed, index;
	private long lastTime, timer;
	private BufferedImage[]frames; //Array used to hold all still images used to make up animation
	//Constructor
	public Animation(int speed, BufferedImage[] frames) {
		super();
		this.speed = speed;
		this.frames = frames;
		index = 0;
		timer = 0;
		lastTime = System.currentTimeMillis();
	}
	//Updates how often the animation changes
	public void update(){
		timer += System.currentTimeMillis() - lastTime;
		lastTime = System.currentTimeMillis();
		if(timer > speed){
			index++;
			timer = 0;
			if(index >= frames.length){
				index = 0;
			}
		}
	}
	//Getters
	public BufferedImage getCurrentFrame(){
		return frames[index];
	}
}
