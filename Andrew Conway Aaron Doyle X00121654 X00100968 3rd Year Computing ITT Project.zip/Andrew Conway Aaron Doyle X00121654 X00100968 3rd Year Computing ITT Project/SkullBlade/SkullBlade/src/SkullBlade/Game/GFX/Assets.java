package SkullBlade.Game.GFX;

import java.awt.image.BufferedImage;
//HOLDS ALL ASSETS SUCH AS IMAGES, MUSIC, ETC.
public class Assets {
	//Attributes
	public static final int width = 103, height = 34;//Standard size for tiles
	//All sprites/still images
	public static BufferedImage skull, skullAlt, brown, chapel, green, house, path, purple, red, white, coin, key1, key2, key3;
	//All animations
	public static BufferedImage[] player_left, player_right, player_attack_right, player_attack_left,
									skullW_left, skullB_left, coin_anim, btn_start;
	
	public static void init(){
		//First sheet for player idle/walking animations
		SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/char_move.png"));
		player_right = new BufferedImage[2];
		player_right[0] = sheet.crop(0, 0, 65, 95);
		player_right[1] = sheet.crop(66, 0, 85, 95);
		player_left = new BufferedImage[2];
		player_left[0] = sheet.crop(235, 0, 65, 95);
		player_left[1] = sheet.crop(150, 0, 85, 95);
		//Player attack animations
		SpriteSheet sheet1 = new SpriteSheet(ImageLoader.loadImage("/textures/player_attack_sheet.png"));
		player_attack_right = new BufferedImage[3];
		player_attack_right[0] = sheet1.crop(0, 0, 75, 95);
		player_attack_right[1] = sheet1.crop(75, 0, 95, 95);
		player_attack_right[2] = sheet1.crop(175, 0, 85, 95);
		player_attack_left = new BufferedImage[3];
		player_attack_left[0] = sheet1.crop(0, 150, 100, 100);
		player_attack_left[1] = sheet1.crop(100, 150, 85, 95);
		player_attack_left[2] = sheet1.crop(180, 150, 85, 95);
		//Standard skull enemy animations
		SpriteSheet sheet2 = new SpriteSheet(ImageLoader.loadImage("/textures/skull_sheet.png"));
		skullW_left = new BufferedImage[2];
		skullW_left[0] = sheet2.crop(0, 0, 150, 140);
		skullW_left[1] = sheet2.crop(150, 0, 150, 140);
		skullB_left = new BufferedImage[2];
		skullB_left[0] = sheet2.crop(0, 150, 150, 150);
		skullB_left[1] = sheet2.crop(150, 140, 150, 150);
		//All tiles
		SpriteSheet sheet3 = new SpriteSheet(ImageLoader.loadImage("/textures/tileSheet.png"));
		green = sheet3.crop(0, 0, width, height);
		white = sheet3.crop(width, 0, width, height);
		red = sheet3.crop(width * 2, 0, width, height);
		purple = sheet3.crop(width * 3, 0, width, height);
		path = sheet3.crop(0, height, width, height);
		brown = sheet3.crop(width , height, width, height);
		house = sheet3.crop(width * 2, height, width, height);
		chapel = sheet3.crop(width * 3, height, width, height);
		//Menu buttons
		SpriteSheet sheet4 = new SpriteSheet(ImageLoader.loadImage("/textures/menu.png"));
		btn_start = new BufferedImage[2];
		btn_start[0] = sheet4.crop(0, 0, 200, 70);
		btn_start[1] = sheet4.crop(0, 70, 200, 70);
		//Coins/items
		SpriteSheet sheet5 = new SpriteSheet(ImageLoader.loadImage("/textures/coin_sheet.png"));
		coin = sheet5.crop(0, 0, 106, 200);
		coin_anim = new BufferedImage[6];
		coin_anim[0] = sheet5.crop(0, 0, 106, 200);
		coin_anim[0] = sheet5.crop(106, 0, 106, 200);
		coin_anim[0] = sheet5.crop(212, 0, 106, 200);
		coin_anim[0] = sheet5.crop(318, 0, 106, 200);
		coin_anim[0] = sheet5.crop(424, 0, 106, 200);
		coin_anim[0] = sheet5.crop(536, 0, 106, 200);
		//To be used for instructions
		SpriteSheet sheet6 = new SpriteSheet(ImageLoader.loadImage("/textures/keyboard.png"));
		key1 = sheet6.crop(66, 127, 20, 20);
		key2 = sheet6.crop(108, 127, 20, 20);
		key3 = sheet6.crop(112, 165, 100, 20);
	}
}
