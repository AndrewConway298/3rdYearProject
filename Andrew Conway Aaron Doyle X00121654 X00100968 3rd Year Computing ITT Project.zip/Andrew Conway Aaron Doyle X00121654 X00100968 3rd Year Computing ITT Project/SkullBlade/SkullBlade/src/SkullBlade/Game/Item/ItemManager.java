package SkullBlade.Game.Item;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

import SkullBlade.Game.Handler;

public class ItemManager {
	//Attributes
	private Handler handler;
	private ArrayList<Item> items;
	//Constructor
	public ItemManager(Handler handler){
		this.handler = handler;
		items = new ArrayList<Item>();
	}
	//Update(Uses iterator to traverse array list of items)
	public void update(){
		Iterator<Item> it  = items.iterator();
		while(it.hasNext()){
			Item i = it.next();
			i.update();
			if(i.getCount() == Item.PICKED_UP){
				it.remove();
			}
		}
	}
	//Renders item i
	public void render(Graphics g){
		for(Item i : items){
			i.render(g);
		}
	}
	//Adds item
	public void additem(Item i){
		i.setHandler(handler);
		items.add(i);
	}
	//Getters
	public Handler getHandler() {
		return handler;
	}
	
	
}
