package SkullBlade.Game.States;

import java.awt.Graphics;
import SkullBlade.Game.Handler;
import SkullBlade.Game.GFX.Assets;
import SkullBlade.Game.UI.ClickListener;
import SkullBlade.Game.UI.UIImageButton;
import SkullBlade.Game.UI.UIManager;

public class MenuState extends State{
	//Attributes
	private UIManager uiManager;
	//Constructor
	public MenuState(Handler handler){
		super(handler);
		uiManager = new UIManager(handler);
		handler.getMouseManager().setUIManager(uiManager);
		
		uiManager.addObject(new UIImageButton(200, 200, 128, 64, Assets.btn_start, new ClickListener(){

			public void onClick() {
				handler.getMouseManager().setUIManager(null);
				State.setState(handler.getGame().gameState);
			}})); 
	}
	//Updates UI manager
	public void update() {
		uiManager.tick();
	}
	//Renders UI manager
	public void render(Graphics g) {
		uiManager.update(g);
	}

}
