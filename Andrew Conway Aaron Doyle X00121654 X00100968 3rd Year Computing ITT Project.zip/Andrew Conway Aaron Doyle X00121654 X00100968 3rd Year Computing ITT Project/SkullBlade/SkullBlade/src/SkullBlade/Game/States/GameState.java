package SkullBlade.Game.States;

import java.awt.Graphics;
import SkullBlade.Game.Handler;
import SkullBlade.Game.Worlds.World;

public class GameState extends State{
	
	//Attributes
	private World world;
	//Constructor
	public GameState(Handler handler){
		super(handler);
		world = new World(handler, "res/worlds/world1.txt");
		handler.setWorld(world);
		handler.getGameCamera().move(100, 200);
	}
	//Updates world
	public void update() {		
		world.update();
	}
	//Renders world
	public void render(Graphics g) {
		world.render(g);	
	}
	
}
