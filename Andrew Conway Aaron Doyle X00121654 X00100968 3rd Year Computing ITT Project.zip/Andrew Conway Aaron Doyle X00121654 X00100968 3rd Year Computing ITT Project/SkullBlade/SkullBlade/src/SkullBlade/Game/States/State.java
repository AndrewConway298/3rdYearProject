package SkullBlade.Game.States;

import java.awt.Graphics;
import SkullBlade.Game.Handler;

public abstract class State {
	//GAME STATE MANAGER
	private static State curState = null;
	
	public static void setState(State state){
		curState = state;
	}
	
	public static State getState(){
		return curState;
	}
	//CLASS
	protected Handler handler;
	
	public State(Handler handler){
		this.handler = handler;
	}
	
	public abstract void update();
	
	public abstract void render(Graphics g);
}
