package SkullBlade.Game.Utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Util {
	//Class used to provide methods useful to multiple classes
	//Loads a string from a file
	public static String loadFileString(String path){
		//Builds a string
		StringBuilder builder = new StringBuilder();
		try{
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line;
			while((line = br.readLine()) != null)
				//skips spaces
				builder.append(line + "\n");
			br.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		return builder.toString();
	}
	//Takes in integers and converts them to type string
	public static int parseInt(String number){
		try{
			return Integer.parseInt(number);
		}catch(NumberFormatException e){
			e.printStackTrace();
			return 0;
		}
	}
}
