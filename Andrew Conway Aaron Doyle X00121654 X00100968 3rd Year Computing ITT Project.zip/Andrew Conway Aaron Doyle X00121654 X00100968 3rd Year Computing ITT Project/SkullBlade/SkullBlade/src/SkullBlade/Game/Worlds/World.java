package SkullBlade.Game.Worlds;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import SkullBlade.Game.Game;
import SkullBlade.Game.Handler;
import SkullBlade.Game.Entities.Entity;
import SkullBlade.Game.Entities.EntityManager;
import SkullBlade.Game.Entities.Creatures.Player;
import SkullBlade.Game.Entities.Creatures.Skull;
import SkullBlade.Game.Entities.Creatures.SkullAlt;
import SkullBlade.Game.GFX.Assets;
import SkullBlade.Game.GFX.ImageLoader;
import SkullBlade.Game.Item.Item;
import SkullBlade.Game.Item.ItemManager;
import SkullBlade.Game.Tiles.Tile;
import SkullBlade.Game.Utils.Util;

public class World {
	//Attributes
	private Handler handler;
	private int width, height;
	private int spawnX, spawnY;
	private int[][] tiles;
	//Entities
	private EntityManager entityManager;
	//Items
	private ItemManager itemManager;
	//Constructor
	public World(Handler handler, String path){
		this.handler = handler;
		entityManager = new EntityManager(handler, new Player(handler, 103, 340));
		itemManager = new ItemManager(handler);
		entityManager.addEntity(new Skull(handler, 450, 300, 139, 140));
		entityManager.addEntity(new Skull(handler, 850, 300, 139, 140));		
		entityManager.addEntity(new Skull(handler, 1250, 300, 139, 140));
		entityManager.addEntity(new SkullAlt(handler, 1650, 300, 136, 140));
		//loadWorld called to keep code clean
		loadWorld(path);
		entityManager.getPlayer().setX(spawnX);
		entityManager.getPlayer().setY(spawnY);
	}
	//Updates managers
	public void update(){
		itemManager.update();
		entityManager.update();
	}
	//Renders World in
	public void render(Graphics g){
		//Uses math package for rendering, allows for tiles that are off screen to be dropped and only the tiles on screen to be rendered
		int xStart = (int) Math.max(0, handler.getGameCamera().getxOffSet() / Tile.LVLWIDTH);
		int xEnd = (int) Math.min(width, (handler.getGameCamera().getxOffSet() + handler.getWidth()) / Tile.LVLWIDTH + 1);
		int yStart = (int) Math.max(0, handler.getGameCamera().getyOffSet() / Tile.LVLHEIGHT);
		int yEnd = (int) Math.min(height, (handler.getGameCamera().getyOffSet() + handler.getHeight()) / Tile.LVLHEIGHT + 1);
		
		for(int y = yStart; y < yEnd; y++){
			for(int x = xStart; x < xEnd; x++){
				getLevel(x, y).render(g, (int)(x * Tile.LVLWIDTH - handler.getGameCamera().getxOffSet()), 
						(int)(y * Tile.LVLHEIGHT - handler.getGameCamera().getyOffSet()));
			}
		}
		//Items
		itemManager.render(g);
		//Entities
		entityManager.render(g);
		//For HUD score display
		g.setColor(Color.GREEN);
		g.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		g.drawString("Score: " +Entity.score, 50, 50);
		g.setColor(Color.YELLOW);
		g.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		g.drawString("Coins: " +Item.coin, 82, 75);
		Item.drawCoin(g, 45, 40);
		//To be used for possible instructions
		//g.drawImage(Assets.key1, 0, 175, 20, 20, null);
		//g.drawImage(Assets.key2, 50, 175, 20, 20, null);
		//g.drawImage(Assets.key3, 0, 200, 70, 20, null);
	}
	//Gets the level built in the appropriate .txt file
	public Tile getLevel (int x, int y){
		if(x < 0 || y < 0 || x >= width || y >= height)
			return Tile.tilePath;
		Tile l = Tile.levels[tiles[x][y]];
		if(l == null){
			return Tile.tilePurple;
			}
		return l;
	}
	//Loads in a world file
	private void loadWorld(String path){
		String file = Util.loadFileString(path);
		String[] tokens = file.split("\\s+");
		width = Util.parseInt(tokens[0]);
		height = Util.parseInt(tokens[1]);
		spawnX = Util.parseInt(tokens[2]);
		spawnY = Util.parseInt(tokens[3]);
		
		tiles = new int[width][height];
		for(int y = 0; y < height; y++){
			for(int x = 0; x < width; x++){
				tiles[x][y] = Util.parseInt(tokens[(x + y * width) + 4]);
			}
		}
	}
	//Getters & Setters
	public int getWidth(){
        return width;
    }
    
    public int getHeight(){
        return height;
    }

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public ItemManager getItemManager() {
		return itemManager;
	}

	public void setItemManager(ItemManager itemManager) {
		this.itemManager = itemManager;
	}

	public Handler getHandler() {
		return handler;
	}

	public void setHandler(Handler handler) {
		this.handler = handler;
	} 
	
	
    
}
