package SkullBlade.Game.Entities.Creatures;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import SkullBlade.Game.Handler;
import SkullBlade.Game.GFX.Animation;
import SkullBlade.Game.GFX.Assets;
import SkullBlade.Game.Item.Item;

public class Skull extends Creature{
	//Attributes
	private Animation animLeft;
	//Constructor
	public Skull(Handler handler, float x, float y, int width, int height) {
		super(handler, x, y, 90, 90);
		bounds.x = 0;
		bounds.y = 0;
		bounds.width = 150;
		bounds.height = 150;
		animLeft = new Animation(100, Assets.skullW_left);
	}
	//Updates animation
	public void update() {
		animLeft.update();
	}

	//Renders current animation
	public void render(Graphics g) {
		g.drawImage(getCurrentAnimation(), (int) (x - handler.getGameCamera().getxOffSet()), (int) (y - handler.getGameCamera().getyOffSet()), null);
	}
	//Upon death. increases score by 150 and drops a coin
	public void die(){
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 60, (int) y + 60));
		score+=150;
	}
	//Checks if entity is solid
	public boolean isSolid(){
		return true;
	}
	//Gets animation
	private BufferedImage getCurrentAnimation(){
			return animLeft.getCurrentFrame();
	}
	
	
}
