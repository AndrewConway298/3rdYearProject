package SkullBlade.Game.Entities.Creatures;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import SkullBlade.Game.Handler;
import SkullBlade.Game.Entities.Entity;
import SkullBlade.Game.GFX.Animation;
import SkullBlade.Game.GFX.Assets;
import SkullBlade.Game.Item.Item;

public class SkullAlt extends Creature{
	//Attributes
	private Animation animLeft;
	//Attack variables
		private long lastAttackTimer, attackCooldown = 350, attackTimer = attackCooldown;
	//Constructor
	public SkullAlt(Handler handler, float x, float y, int width, int height) {
		super(handler, x, y, 90, 90);
		bounds.x = 0;
		bounds.y = 0;
		bounds.width = 150;
		bounds.height = 150;
		health = 15;
		animLeft = new Animation(100, Assets.skullB_left);
	}
	//Updates animation
	public void update() {
		animLeft.update();
		checkAttacks();
	}
	//Renders current animation
	public void render(Graphics g) {
		g.drawImage(getCurrentAnimation(), (int) (x - handler.getGameCamera().getxOffSet()), (int) (y - handler.getGameCamera().getyOffSet()), null);
	}
	//Attack made for 
	private void checkAttacks(){
		//Sets a cooldown for the attack
		attackTimer += System.currentTimeMillis() - lastAttackTimer;
		lastAttackTimer = System.currentTimeMillis();
		if(attackTimer < attackCooldown){
			return;
		}
		//Sets up attack bounds
		Rectangle cb = getCollisionBounds(0, 0);
		Rectangle ar = new Rectangle();
		int arSize = 25;
		ar.width = arSize;
		ar.height = arSize;
				//left
				ar.x = cb.x - arSize;
				ar.y = cb.y + cb.height / 2 - arSize / 2;
		//Resets attack timer after attack is complete
		attackTimer = 0;
		//Checks against entity and if collision is present will cause damage
		for(Entity e : handler.getWorld().getEntityManager().getEntities()){
			if(e.equals(this)){
				continue;
			}
			if(e.getCollisionBounds(0, 0).intersects(ar)){
				e.hurt(1);
				return;
			}
		}
	}
	//Designed to be a boss so drops multiple coins and offers a bigger score
	public void die(){
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 30, (int) y + 60));
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 60, (int) y + 60));
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 90, (int) y + 60));
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 120, (int) y + 60));
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 150, (int) y + 60));
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 45, (int) y + 40));
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 75, (int) y + 40));
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 105, (int) y + 40));
		handler.getWorld().getItemManager().additem(Item.coinItem.createNew((int) x + 135, (int) y + 40));
		score+=887;
		
	}
	//Checks if entity is solid
	public boolean isSolid(){
		return true;
	}
	//Gets current animation
	private BufferedImage getCurrentAnimation(){
			return animLeft.getCurrentFrame();
	}
}
