package SkullBlade.Game.Entities.Creatures;

import SkullBlade.Game.Handler;
import SkullBlade.Game.Entities.Entity;
import SkullBlade.Game.Tiles.Tile;

public abstract class Creature extends Entity{
	//Sets standards for creature
	public static final float DEFAULT_SPEED = 3.0f;
	public static final int DEFAULT_CREATURE_WIDTH = 64, DEFAULT_CREATURE_HEIGHT = 64;
	protected float speed;
	protected float xMove;
	//Constructor
	public Creature(Handler handler, float x, float y, int width, int height) {
		super(handler, x, y, width, height);
		speed = DEFAULT_SPEED;
		xMove = 0;

	}
	//Main move method, checks for collision and calls individual move methods for both axis
	public void move(){
		if(!checkEntityCollision(xMove, 0f))
			moveX();
	}
	//Move methods for X-Axis
	public void moveX(){
		if(xMove > 0){
			//Checks for collision going left
			int tx = (int)(x + xMove + bounds.x + bounds.width) / Tile.LVLWIDTH;
			if(!collisionWithTile(tx, (int) (y + bounds.y) / Tile.LVLHEIGHT) && 
					!collisionWithTile(tx, (int) (y + bounds.y + bounds.height) / Tile.LVLHEIGHT)){
				x += xMove;
			}else{
				x = tx * Tile.LVLWIDTH - bounds.x - bounds.width - 1;
			}
		}
		else if(xMove < 0){
			//Checks for collision going right
			int tx = (int)(x + xMove + bounds.x) / Tile.LVLWIDTH;
			if(!collisionWithTile(tx, (int) (y + bounds.y) / Tile.LVLHEIGHT) && 
					!collisionWithTile(tx, (int) (y + bounds.y + bounds.height) / Tile.LVLHEIGHT)){
				x += xMove;
			}else{
				x = tx * Tile.LVLWIDTH + Tile.LVLWIDTH - bounds.x;
			}
		}
	}
	
	public boolean collisionWithTile(int x, int y){
		return handler.getWorld().getLevel(x, y).isSolid();
	}
	
	//Getters & Setters
	public float getxMove() {
		return xMove;
	}

	public void setxMove(float xMove) {
		this.xMove = xMove;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}

}
