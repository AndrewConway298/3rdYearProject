package SkullBlade.Game.Entities.Creatures;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import SkullBlade.Game.Handler;
import SkullBlade.Game.Entities.Entity;
import SkullBlade.Game.GFX.Animation;
import SkullBlade.Game.GFX.Assets;

public class Player extends Creature{
	//Animations
	private Animation animLeft, animRight, attackL, attackR;
	//Attack variables
	private long lastAttackTimer, attackCooldown = 350, attackTimer = attackCooldown;
	//Constructor
	public Player(Handler handler, float x, float y) {
		super(handler, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
		bounds.x = 12;
		bounds.y = 0;
		bounds.width = 32;
		bounds.height = 90;
		health = 25;
		//Sets animations
		animLeft = new Animation(375, Assets.player_left);
		animRight = new Animation(375, Assets.player_right);
		attackL = new Animation(175, Assets.player_attack_left);
		attackR = new Animation(175, Assets.player_attack_right);
	}
	//Update
	public void update() {
		//Animations
		animLeft.update();
		animRight.update();
		getInput();
		move();
		handler.getGameCamera().centerOnEntity(this);
		//Attack Inputs
		checkAttacks();
		attackL.update();
		attackR.update();
	}
	//Checks for an attack
	private void checkAttacks(){
		//Sets a cooldown for the attack
		attackTimer += System.currentTimeMillis() - lastAttackTimer;
		lastAttackTimer = System.currentTimeMillis();
		if(attackTimer < attackCooldown){
			return;
		}
		//Sets up attack bounds
		Rectangle cb = getCollisionBounds(0, 0);
		Rectangle ar = new Rectangle();
		int arSize = 25;
		ar.width = arSize;
		ar.height = arSize;
		//Checks for attack key being pressed
		if(handler.getKeyManager().space){
			if(handler.getKeyManager().left){
				//left
				ar.x = cb.x - arSize;
				ar.y = cb.y + cb.height / 2 - arSize / 2;
			}
			else{
				//right
			ar.x = cb.x + cb.width;
			ar.y = cb.y + cb.height / 2 - arSize / 2;
			}
		}
		else{
			return;
		}
		//Resets attack timer after attack is complete
		attackTimer = 0;
		//Checks against entity and if collision is present will cause damage
		for(Entity e : handler.getWorld().getEntityManager().getEntities()){
			if(e.equals(this)){
				continue;
			}
			if(e.getCollisionBounds(0, 0).intersects(ar)){
				e.hurt(1);
				return;
			}
		}
	}
	//Prints out to console if player dies
	public void die(){
		System.out.println("You lose!");
	}
	//Checks keys
	private void getInput(){
		xMove = 0;
		if(handler.getKeyManager().left)
			xMove = -speed;
		if(handler.getKeyManager().right)
			xMove = speed;
	}
	@Override
	public void render(Graphics g) {
	g.drawImage(getCurrentAnimation(), (int) (x - handler.getGameCamera().getxOffSet()), (int) (y - handler.getGameCamera().getyOffSet()), null);
	}
	//Gets animation of current frame
	private BufferedImage getCurrentAnimation(){
		//if/else's used to change animations from left and right
		if(xMove < 0){
			return animLeft.getCurrentFrame();
		}
		else if(handler.getKeyManager().space){
			if(handler.getKeyManager().left){
				return attackL.getCurrentFrame();
			}
			else {
				return attackR.getCurrentFrame();
			}
		}
		else 
			return animRight.getCurrentFrame();
	}

}
