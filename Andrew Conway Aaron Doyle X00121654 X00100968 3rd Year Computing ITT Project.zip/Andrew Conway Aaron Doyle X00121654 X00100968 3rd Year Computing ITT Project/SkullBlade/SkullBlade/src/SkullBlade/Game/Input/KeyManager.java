package SkullBlade.Game.Input;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyManager implements KeyListener {
	//Attributes
	private boolean [] keys;
	public boolean left, right, space;
	//Constructor
	public KeyManager(){
		keys = new boolean[256];
	}
	//Updates if keys being pressed
	public void update(){
		left = keys[KeyEvent.VK_A];
		right = keys[KeyEvent.VK_D];
		space = keys[KeyEvent.VK_SPACE];
	}
	//Checks if key is pressed
	public void keyPressed(KeyEvent e) {
		keys[e.getKeyCode()] = true;
	}
	//Checks if key is released
	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false;
	}
	//Monitors keys
	public void keyTyped(KeyEvent e) {
		
	}

}
