package SkullBlade.Game.Input;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import SkullBlade.Game.UI.UIManager;


public class MouseManager implements MouseListener, MouseMotionListener{
	//Attributes
	private boolean leftPressed, rightPressed;
	private int mouseX, mouseY;
	private UIManager uiManager;
	//Constructor
	public MouseManager(){
		
	}
	//Checks for pressed
	public boolean isLeftPressed(){
		return leftPressed;
	}
	
	public boolean isRightPressed(){
		return rightPressed;
	}
	//Checks if mouse is dragged
	public void mouseDragged(MouseEvent e) {
		
	}
	//Keeps track of mouse
	public void mouseMoved(MouseEvent e) {
		mouseX = e.getX();
		mouseY = e.getY();
	}
	public void mouseClicked(MouseEvent e) {
		
	}

	public void mouseEntered(MouseEvent e) {
		
	}

	public void mouseExited(MouseEvent e) {
		
	}
	//Checks when mouse is clicked down
	public void mousePressed(MouseEvent e) {
		if(e.getButton() == MouseEvent.BUTTON1){
			leftPressed = true;
		}
		else if(e.getButton() == MouseEvent.BUTTON3){
			rightPressed = true;
		}
		
		if(uiManager!= null){
			uiManager.onMouseMove(e);
		}
	}
	//Checks when mouse is released
	public void mouseReleased(MouseEvent e) {
		if(e.getButton() == MouseEvent.BUTTON1){
			leftPressed = false;
		}
		else if(e.getButton() == MouseEvent.BUTTON3){
			rightPressed = false;
		}
		
		if(uiManager!=null){
			uiManager.onMouseRelease(e);
		}
		
	}
	//Getters & Setters
	public int getMouseX(){
		return mouseX;
	}
	
	public int getMouseY(){
		return mouseY;
	}
	
	public void setUIManager(UIManager uiManager){
		this.uiManager = uiManager;
	}

}
